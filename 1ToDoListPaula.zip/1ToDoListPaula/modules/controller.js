/*
* Author: Paula O'Connor
* Assignment: WE4.1 Mobile Web Application, Digital Skills Academy
* Assignment 2: A To Do Application written in AngularJS
* DIT programme code is DT7003, 2015/2016
* Student ID: D15128648
* Date: 2016/09/23
* Ref: Lecture notes, www.w3schools.com, bootsnipp.com, www.youtube.com, Get Coding by Walker Books, Programming Knowledge Channel.
* Ref: http://www.w3schools.com/angular/tryit.asp?filename=try_ng_todo_app
*
* In this file we just have the controller for the todo list.
* As text is input it is displayed on the screen.
* A ToDo item can be selected and deleted. Refresing with updated list.
*/


var app = angular.module('myApp', []);
app.controller('todoCtrl', function($scope) {
    $scope.todoList = [{todoText:'Angular Assignment', done:false}];

    $scope.todoAdd = function() {
        $scope.todoList.push({todoText:$scope.todoInput, done:false});
        $scope.todoInput = "";
    };

    $scope.remove = function() {
        var oldList = $scope.todoList;
        $scope.todoList = [];
        angular.forEach(oldList, function(x) {
            if (!x.done) $scope.todoList.push(x);
        });
    };
});
